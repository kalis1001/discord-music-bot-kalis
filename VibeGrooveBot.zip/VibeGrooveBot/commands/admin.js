const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('admin')
        .setDescription('Lệnh quản lý server')
        .addSubcommand(subcommand =>
            subcommand
                .setName('ban')
                .setDescription('Cấm thành viên')
                .addUserOption(option => 
                    option.setName('user')
                        .setDescription('Thành viên cần cấm')
                        .setRequired(true))
                .addStringOption(option =>
                    option.setName('reason')
                        .setDescription('Lý do cấm')
                        .setRequired(false)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('kick')
                .setDescription('Đuổi thành viên')
                .addUserOption(option => 
                    option.setName('user')
                        .setDescription('Thành viên cần đuổi')
                        .setRequired(true))
                .addStringOption(option =>
                    option.setName('reason')
                        .setDescription('Lý do đuổi')
                        .setRequired(false)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('avatar')
                .setDescription('Xem avatar của thành viên')
                .addUserOption(option => 
                    option.setName('user')
                        .setDescription('Thành viên cần xem avatar')
                        .setRequired(false)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('voicetime')
                .setDescription('Xem thời gian treo voice của thành viên')
                .addUserOption(option => 
                    option.setName('user')
                        .setDescription('Thành viên cần xem thời gian voice')
                        .setRequired(false)))
        .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();

        try {
            switch (subcommand) {
                case 'ban':
                    await this.handleBan(interaction);
                    break;
                case 'kick':
                    await this.handleKick(interaction);
                    break;
                case 'avatar':
                    await this.handleAvatar(interaction);
                    break;
                case 'voicetime':
                    await this.handleVoiceTime(interaction);
                    break;
                default:
                    await interaction.reply({
                        content: '❌ Lệnh không hợp lệ!',
                        ephemeral: true
                    });
            }
        } catch (error) {
            console.error('Lỗi khi thực hiện lệnh admin:', error);
            await interaction.reply({
                content: '❌ Đã xảy ra lỗi khi thực hiện lệnh!',
                ephemeral: true
            });
        }
    },

    async handleBan(interaction) {
        const user = interaction.options.getUser('user');
        const reason = interaction.options.getString('reason') || 'Không có lý do';

        // Kiểm tra quyền
        if (!interaction.member.permissions.has(PermissionFlagsBits.BanMembers)) {
            return await interaction.reply({
                content: '❌ Bạn không có quyền cấm thành viên!',
                ephemeral: true
            });
        }

        // Kiểm tra xem có thể cấm user không
        const member = await interaction.guild.members.fetch(user.id).catch(() => null);
        if (!member) {
            return await interaction.reply({
                content: '❌ Không tìm thấy thành viên này trong server!',
                ephemeral: true
            });
        }

        if (member.id === interaction.user.id) {
            return await interaction.reply({
                content: '❌ Bạn không thể tự cấm chính mình!',
                ephemeral: true
            });
        }

        if (member.id === interaction.client.user.id) {
            return await interaction.reply({
                content: '❌ Không thể cấm bot!',
                ephemeral: true
            });
        }

        if (member.roles.highest.position >= interaction.member.roles.highest.position) {
            return await interaction.reply({
                content: '❌ Bạn không thể cấm thành viên có vai trò cao hơn hoặc bằng bạn!',
                ephemeral: true
            });
        }

        try {
            await member.ban({ reason: reason });
            
            const embed = new EmbedBuilder()
                .setColor('#ff0000')
                .setTitle('🔨 Thành viên đã bị cấm')
                .setDescription(`**${user.tag}** đã bị cấm khỏi server`)
                .addFields(
                    { name: '👤 Thành viên', value: `${user.tag} (${user.id})`, inline: true },
                    { name: '👮 Người cấm', value: `${interaction.user.tag}`, inline: true },
                    { name: '📝 Lý do', value: reason, inline: false }
                )
                .setThumbnail(user.displayAvatarURL({ dynamic: true }))
                .setTimestamp();

            await interaction.reply({ embeds: [embed] });
        } catch (error) {
            console.error('Lỗi khi cấm thành viên:', error);
            await interaction.reply({
                content: '❌ Không thể cấm thành viên này!',
                ephemeral: true
            });
        }
    },

    async handleKick(interaction) {
        const user = interaction.options.getUser('user');
        const reason = interaction.options.getString('reason') || 'Không có lý do';

        // Kiểm tra quyền
        if (!interaction.member.permissions.has(PermissionFlagsBits.KickMembers)) {
            return await interaction.reply({
                content: '❌ Bạn không có quyền đuổi thành viên!',
                ephemeral: true
            });
        }

        // Kiểm tra xem có thể đuổi user không
        const member = await interaction.guild.members.fetch(user.id).catch(() => null);
        if (!member) {
            return await interaction.reply({
                content: '❌ Không tìm thấy thành viên này trong server!',
                ephemeral: true
            });
        }

        if (member.id === interaction.user.id) {
            return await interaction.reply({
                content: '❌ Bạn không thể tự đuổi chính mình!',
                ephemeral: true
            });
        }

        if (member.id === interaction.client.user.id) {
            return await interaction.reply({
                content: '❌ Không thể đuổi bot!',
                ephemeral: true
            });
        }

        if (member.roles.highest.position >= interaction.member.roles.highest.position) {
            return await interaction.reply({
                content: '❌ Bạn không thể đuổi thành viên có vai trò cao hơn hoặc bằng bạn!',
                ephemeral: true
            });
        }

        try {
            await member.kick(reason);
            
            const embed = new EmbedBuilder()
                .setColor('#ff9900')
                .setTitle('👢 Thành viên đã bị đuổi')
                .setDescription(`**${user.tag}** đã bị đuổi khỏi server`)
                .addFields(
                    { name: '👤 Thành viên', value: `${user.tag} (${user.id})`, inline: true },
                    { name: '👮 Người đuổi', value: `${interaction.user.tag}`, inline: true },
                    { name: '📝 Lý do', value: reason, inline: false }
                )
                .setThumbnail(user.displayAvatarURL({ dynamic: true }))
                .setTimestamp();

            await interaction.reply({ embeds: [embed] });
        } catch (error) {
            console.error('Lỗi khi đuổi thành viên:', error);
            await interaction.reply({
                content: '❌ Không thể đuổi thành viên này!',
                ephemeral: true
            });
        }
    },

    async handleAvatar(interaction) {
        const user = interaction.options.getUser('user') || interaction.user;
        
        const embed = new EmbedBuilder()
            .setColor('#00ff00')
            .setTitle(`🖼️ Avatar của ${user.tag}`)
            .setDescription(`[Tải về avatar](${user.displayAvatarURL({ dynamic: true, size: 1024 })})`)
            .setImage(user.displayAvatarURL({ dynamic: true, size: 1024 }))
            .addFields(
                { name: '👤 Thành viên', value: `${user.tag}`, inline: true },
                { name: '🆔 ID', value: `${user.id}`, inline: true },
                { name: '📅 Tạo tài khoản', value: `<t:${Math.floor(user.createdAt.getTime() / 1000)}:R>`, inline: true }
            )
            .setFooter({ text: `Được yêu cầu bởi ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
            .setTimestamp();

        await interaction.reply({ embeds: [embed] });
    },

    async handleVoiceTime(interaction) {
        const user = interaction.options.getUser('user') || interaction.user;
        const member = await interaction.guild.members.fetch(user.id).catch(() => null);
        
        if (!member) {
            return await interaction.reply({
                content: '❌ Không tìm thấy thành viên này trong server!',
                ephemeral: true
            });
        }

        const voiceState = member.voice;
        const embed = new EmbedBuilder()
            .setColor('#0099ff')
            .setTitle(`🎤 Thông tin Voice của ${user.tag}`)
            .setThumbnail(user.displayAvatarURL({ dynamic: true }))
            .addFields(
                { name: '👤 Thành viên', value: `${user.tag}`, inline: true },
                { name: '🆔 ID', value: `${user.id}`, inline: true }
            )
            .setFooter({ text: `Được yêu cầu bởi ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
            .setTimestamp();

        if (voiceState.channel) {
            embed.addFields(
                { name: '🔊 Kênh Voice hiện tại', value: `${voiceState.channel.name}`, inline: true },
                { name: '🎯 Trạng thái', value: '🟢 Đang trong voice', inline: true },
                { name: '🔇 Tắt tiếng', value: voiceState.mute ? '✅ Có' : '❌ Không', inline: true },
                { name: '🔇 Tắt mic', value: voiceState.deaf ? '✅ Có' : '❌ Không', inline: true }
            );

            // Tính thời gian join (ước tính)
            const joinTime = voiceState.channel.joinedTimestamp || Date.now();
            const timeInVoice = Date.now() - joinTime;
            const hours = Math.floor(timeInVoice / (1000 * 60 * 60));
            const minutes = Math.floor((timeInVoice % (1000 * 60 * 60)) / (1000 * 60));
            const seconds = Math.floor((timeInVoice % (1000 * 60)) / 1000);

            embed.addFields(
                { name: '⏱️ Thời gian trong voice (phiên này)', value: `${hours}h ${minutes}m ${seconds}s`, inline: false }
            );
        } else {
            embed.addFields(
                { name: '🔊 Kênh Voice hiện tại', value: 'Không có', inline: true },
                { name: '🎯 Trạng thái', value: '🔴 Không trong voice', inline: true },
                { name: '⏱️ Thời gian trong voice', value: '0h 0m 0s', inline: false }
            );
        }

        // Thêm thông tin về thời gian join server
        if (member.joinedAt) {
            embed.addFields(
                { name: '📅 Tham gia server', value: `<t:${Math.floor(member.joinedAt.getTime() / 1000)}:R>`, inline: true }
            );
        }

        await interaction.reply({ embeds: [embed] });
    },

    // Prefix command handlers
    async executePrefix(message, args, action) {
        const prefix = 'k';
        
        switch (action) {
            case 'ban':
                await this.handleBanPrefix(message, args);
                break;
            case 'kick':
                await this.handleKickPrefix(message, args);
                break;
            case 'avatar':
                await this.handleAvatarPrefix(message, args);
                break;
            case 'voicetime':
                await this.handleVoiceTimePrefix(message, args);
                break;
            default:
                await message.reply('❌ Lệnh không hợp lệ!');
        }
    },

    async handleBanPrefix(message, args) {
        if (!message.member.permissions.has(PermissionFlagsBits.BanMembers)) {
            return await message.reply('❌ Bạn không có quyền cấm thành viên!');
        }

        const userMention = message.mentions.users.first();
        if (!userMention) {
            return await message.reply('❌ Vui lòng mention thành viên cần cấm! Ví dụ: `kban @user lý do`');
        }

        const reason = args.slice(1).join(' ') || 'Không có lý do';
        const member = await message.guild.members.fetch(userMention.id).catch(() => null);
        
        if (!member) {
            return await message.reply('❌ Không tìm thấy thành viên này trong server!');
        }

        if (member.id === message.author.id) {
            return await message.reply('❌ Bạn không thể tự cấm chính mình!');
        }

        if (member.roles.highest.position >= message.member.roles.highest.position) {
            return await message.reply('❌ Bạn không thể cấm thành viên có vai trò cao hơn hoặc bằng bạn!');
        }

        try {
            await member.ban({ reason: reason });
            
            const embed = new EmbedBuilder()
                .setColor('#ff0000')
                .setTitle('🔨 Thành viên đã bị cấm')
                .setDescription(`**${userMention.tag}** đã bị cấm khỏi server`)
                .addFields(
                    { name: '👤 Thành viên', value: `${userMention.tag} (${userMention.id})`, inline: true },
                    { name: '👮 Người cấm', value: `${message.author.tag}`, inline: true },
                    { name: '📝 Lý do', value: reason, inline: false }
                )
                .setThumbnail(userMention.displayAvatarURL({ dynamic: true }))
                .setTimestamp();

            await message.reply({ embeds: [embed] });
        } catch (error) {
            console.error('Lỗi khi cấm thành viên:', error);
            await message.reply('❌ Không thể cấm thành viên này!');
        }
    },

    async handleKickPrefix(message, args) {
        if (!message.member.permissions.has(PermissionFlagsBits.KickMembers)) {
            return await message.reply('❌ Bạn không có quyền đuổi thành viên!');
        }

        const userMention = message.mentions.users.first();
        if (!userMention) {
            return await message.reply('❌ Vui lòng mention thành viên cần đuổi! Ví dụ: `kkick @user lý do`');
        }

        const reason = args.slice(1).join(' ') || 'Không có lý do';
        const member = await message.guild.members.fetch(userMention.id).catch(() => null);
        
        if (!member) {
            return await message.reply('❌ Không tìm thấy thành viên này trong server!');
        }

        if (member.id === message.author.id) {
            return await message.reply('❌ Bạn không thể tự đuổi chính mình!');
        }

        if (member.roles.highest.position >= message.member.roles.highest.position) {
            return await message.reply('❌ Bạn không thể đuổi thành viên có vai trò cao hơn hoặc bằng bạn!');
        }

        try {
            await member.kick(reason);
            
            const embed = new EmbedBuilder()
                .setColor('#ff9900')
                .setTitle('👢 Thành viên đã bị đuổi')
                .setDescription(`**${userMention.tag}** đã bị đuổi khỏi server`)
                .addFields(
                    { name: '👤 Thành viên', value: `${userMention.tag} (${userMention.id})`, inline: true },
                    { name: '👮 Người đuổi', value: `${message.author.tag}`, inline: true },
                    { name: '📝 Lý do', value: reason, inline: false }
                )
                .setThumbnail(userMention.displayAvatarURL({ dynamic: true }))
                .setTimestamp();

            await message.reply({ embeds: [embed] });
        } catch (error) {
            console.error('Lỗi khi đuổi thành viên:', error);
            await message.reply('❌ Không thể đuổi thành viên này!');
        }
    },

    async handleAvatarPrefix(message, args) {
        const user = message.mentions.users.first() || message.author;
        
        const embed = new EmbedBuilder()
            .setColor('#00ff00')
            .setTitle(`🖼️ Avatar của ${user.tag}`)
            .setDescription(`[Tải về avatar](${user.displayAvatarURL({ dynamic: true, size: 1024 })})`)
            .setImage(user.displayAvatarURL({ dynamic: true, size: 1024 }))
            .addFields(
                { name: '👤 Thành viên', value: `${user.tag}`, inline: true },
                { name: '🆔 ID', value: `${user.id}`, inline: true },
                { name: '📅 Tạo tài khoản', value: `<t:${Math.floor(user.createdAt.getTime() / 1000)}:R>`, inline: true }
            )
            .setFooter({ text: `Được yêu cầu bởi ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true }) })
            .setTimestamp();

        await message.reply({ embeds: [embed] });
    },

    async handleVoiceTimePrefix(message, args) {
        const user = message.mentions.users.first() || message.author;
        const member = await message.guild.members.fetch(user.id).catch(() => null);
        
        if (!member) {
            return await message.reply('❌ Không tìm thấy thành viên này trong server!');
        }

        const voiceState = member.voice;
        const embed = new EmbedBuilder()
            .setColor('#0099ff')
            .setTitle(`🎤 Thông tin Voice của ${user.tag}`)
            .setThumbnail(user.displayAvatarURL({ dynamic: true }))
            .addFields(
                { name: '👤 Thành viên', value: `${user.tag}`, inline: true },
                { name: '🆔 ID', value: `${user.id}`, inline: true }
            )
            .setFooter({ text: `Được yêu cầu bởi ${message.author.tag}`, iconURL: message.author.displayAvatarURL({ dynamic: true }) })
            .setTimestamp();

        if (voiceState.channel) {
            embed.addFields(
                { name: '🔊 Kênh Voice hiện tại', value: `${voiceState.channel.name}`, inline: true },
                { name: '🎯 Trạng thái', value: '🟢 Đang trong voice', inline: true },
                { name: '🔇 Tắt tiếng', value: voiceState.mute ? '✅ Có' : '❌ Không', inline: true },
                { name: '🔇 Tắt mic', value: voiceState.deaf ? '✅ Có' : '❌ Không', inline: true }
            );
        } else {
            embed.addFields(
                { name: '🔊 Kênh Voice hiện tại', value: 'Không có', inline: true },
                { name: '🎯 Trạng thái', value: '🔴 Không trong voice', inline: true },
                { name: '⏱️ Thời gian trong voice', value: '0h 0m 0s', inline: false }
            );
        }

        if (member.joinedAt) {
            embed.addFields(
                { name: '📅 Tham gia server', value: `<t:${Math.floor(member.joinedAt.getTime() / 1000)}:R>`, inline: true }
            );
        }

        await message.reply({ embeds: [embed] });
    }
};