const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { joinVoiceChannel, createAudioPlayer, createAudioResource, AudioPlayerStatus, VoiceConnectionStatus, entersState } = require('@discordjs/voice');
const Queue = require('../utils/queue');
const Player = require('../utils/player');
const YouTube = require('../utils/youtube');
const Spotify = require('../utils/spotify');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('nhac')
        .setDescription('Điều khiển nhạc')
        .addSubcommand(subcommand =>
            subcommand
                .setName('phat')
                .setDescription('Phát nhạc từ YouTube')
                .addStringOption(option =>
                    option.setName('url')
                        .setDescription('URL YouTube hoặc tên bài hát')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('tam_dung')
                .setDescription('Tạm dừng nhạc'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('tiep_tuc')
                .setDescription('Tiếp tục phát nhạc'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('dung')
                .setDescription('Dừng nhạc và xóa hàng đợi'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('bo_qua')
                .setDescription('Bỏ qua bài hát hiện tại'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('hang_doi')
                .setDescription('Hiển thị hàng đợi nhạc'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('am_luong')
                .setDescription('Điều chỉnh âm lượng')
                .addIntegerOption(option =>
                    option.setName('muc')
                        .setDescription('Mức âm lượng (1-100)')
                        .setMinValue(1)
                        .setMaxValue(100)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('dang_phat')
                .setDescription('Hiển thị bài hát đang phát'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('thoat')
                .setDescription('Rời khỏi kênh voice'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('xoa_hang_doi')
                .setDescription('Xóa toàn bộ hàng đợi'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('tron_bai')
                .setDescription('Trộn thứ tự bài hát trong hàng đợi')),

    async execute(interaction) {
        const subcommand = interaction.options.getSubcommand();
        const guildId = interaction.guild.id;
        
        // Kiểm tra xem user có trong voice channel không
        const voiceChannel = interaction.member.voice.channel;
        if (!voiceChannel && ['phat', 'tam_dung', 'tiep_tuc', 'dung', 'bo_qua', 'am_luong'].includes(subcommand)) {
            return await interaction.reply({
                content: '❌ Bạn phải ở trong một kênh voice để sử dụng lệnh này!',
                ephemeral: true
            });
        }

        // Lấy queue của guild
        let queue = interaction.client.queues.get(guildId);
        
        switch (subcommand) {
            case 'phat':
                const url = interaction.options.getString('url');
                await this.handlePlay(interaction, voiceChannel, url);
                break;
                
            case 'tam_dung':
                await this.handlePause(interaction, queue);
                break;
                
            case 'tiep_tuc':
                await this.handleResume(interaction, queue);
                break;
                
            case 'dung':
                await this.handleStop(interaction, queue);
                break;
                
            case 'bo_qua':
                await this.handleSkip(interaction, queue);
                break;
                
            case 'hang_doi':
                await this.handleQueue(interaction, queue);
                break;
                
            case 'am_luong':
                const volume = interaction.options.getInteger('muc');
                await this.handleVolume(interaction, queue, volume);
                break;
                
            case 'dang_phat':
                await this.handleNowPlaying(interaction, queue);
                break;
                
            case 'thoat':
                await this.handleLeave(interaction, queue);
                break;
                
            case 'xoa_hang_doi':
                await this.handleClearQueue(interaction, queue);
                break;
                
            case 'tron_bai':
                await this.handleShuffle(interaction, queue);
                break;
        }
    },

    async handlePlay(interaction, voiceChannel, url) {
        await interaction.deferReply();
        
        try {
            // Tìm kiếm hoặc lấy thông tin video
            const videoInfo = await YouTube.getVideoInfo(url);
            
            if (!videoInfo) {
                return await interaction.editReply('❌ Không thể tìm thấy video hoặc URL không hợp lệ!');
            }

            const guildId = interaction.guild.id;
            let queue = interaction.client.queues.get(guildId);
            
            // Tạo queue mới nếu chưa có
            if (!queue) {
                queue = new Queue(guildId);
                interaction.client.queues.set(guildId, queue);
            }

            // Thêm bài hát vào queue
            const song = {
                title: videoInfo.videoDetails.title,
                url: videoInfo.videoDetails.video_url,
                duration: videoInfo.videoDetails.lengthSeconds,
                thumbnail: videoInfo.videoDetails.thumbnails[0]?.url,
                requester: interaction.user.username
            };

            queue.addSong(song);

            // Tạo embed thông báo
            const embed = new EmbedBuilder()
                .setColor('#00ff00')
                .setTitle('🎵 Đã thêm vào hàng đợi')
                .setDescription(`**${song.title}**`)
                .setThumbnail(song.thumbnail)
                .addFields(
                    { name: 'Thời lượng', value: this.formatDuration(song.duration), inline: true },
                    { name: 'Yêu cầu bởi', value: song.requester, inline: true },
                    { name: 'Vị trí trong hàng đợi', value: `${queue.songs.length}`, inline: true }
                );

            await interaction.editReply({ embeds: [embed] });

            // Nếu không có player hoặc player không hoạt động, tạo mới
            if (!queue.player || !queue.connection) {
                await this.createPlayer(interaction, voiceChannel, queue);
            }

            // Bắt đầu phát nếu đây là bài đầu tiên
            if (queue.songs.length === 1) {
                await this.playNextSong(queue);
            }

        } catch (error) {
            console.error('Lỗi khi phát nhạc:', error);
            await interaction.editReply('❌ Đã xảy ra lỗi khi phát nhạc. Vui lòng thử lại!');
        }
    },

    async createPlayer(interaction, voiceChannel, queue) {
        // Tạo kết nối voice
        const connection = joinVoiceChannel({
            channelId: voiceChannel.id,
            guildId: interaction.guild.id,
            adapterCreator: interaction.guild.voiceAdapterCreator,
        });

        // Tạo audio player
        const player = new Player(queue);
        
        // Gán player và connection vào queue
        queue.setPlayer(player);
        queue.setConnection(connection);
        
        // Subscribe connection với player
        connection.subscribe(player.audioPlayer);

        // Xử lý sự kiện khi kết nối bị ngắt
        connection.on(VoiceConnectionStatus.Disconnected, () => {
            queue.destroy();
            interaction.client.queues.delete(interaction.guild.id);
        });
    },

    async playNextSong(queue) {
        if (queue.songs.length === 0) {
            return;
        }

        const song = queue.songs[0];
        
        try {
            const stream = await YouTube.getAudioStream(song.url);
            const resource = createAudioResource(stream, {
                inputType: stream.type,
                metadata: song
            });

            queue.player.play(resource);
            queue.currentSong = song;
            
        } catch (error) {
            console.error('Lỗi khi phát bài hát:', error);
            queue.songs.shift(); // Bỏ bài hát lỗi
            if (queue.songs.length > 0) {
                await this.playNextSong(queue);
            }
        }
    },

    async handlePause(interaction, queue) {
        if (!queue || !queue.player) {
            return await interaction.reply({
                content: '❌ Không có nhạc nào đang phát!',
                ephemeral: true
            });
        }

        queue.player.pause();
        await interaction.reply('⏸️ Đã tạm dừng nhạc');
    },

    async handleResume(interaction, queue) {
        if (!queue || !queue.player) {
            return await interaction.reply({
                content: '❌ Không có nhạc nào đang phát!',
                ephemeral: true
            });
        }

        queue.player.resume();
        await interaction.reply('▶️ Đã tiếp tục phát nhạc');
    },

    async handleStop(interaction, queue) {
        if (!queue) {
            return await interaction.reply({
                content: '❌ Không có nhạc nào đang phát!',
                ephemeral: true
            });
        }

        queue.destroy();
        interaction.client.queues.delete(interaction.guild.id);
        await interaction.reply('⏹️ Đã dừng nhạc và xóa hàng đợi');
    },

    async handleSkip(interaction, queue) {
        if (!queue || queue.songs.length === 0) {
            return await interaction.reply({
                content: '❌ Không có bài hát nào để bỏ qua!',
                ephemeral: true
            });
        }

        const skippedSong = queue.songs.shift();
        await interaction.reply(`⏭️ Đã bỏ qua: **${skippedSong.title}**`);
        
        if (queue.songs.length > 0) {
            await this.playNextSong(queue);
        } else {
            queue.player.stop();
        }
    },

    async handleQueue(interaction, queue) {
        if (!queue || queue.songs.length === 0) {
            return await interaction.reply({
                content: '❌ Hàng đợi trống!',
                ephemeral: true
            });
        }

        const embed = new EmbedBuilder()
            .setColor('#0099ff')
            .setTitle('🎵 Hàng đợi nhạc')
            .setDescription(
                queue.songs.slice(0, 10).map((song, index) => {
                    const status = index === 0 ? '🎵 **Đang phát:**' : `${index}.`;
                    return `${status} ${song.title} - *${song.requester}*`;
                }).join('\n')
            )
            .setFooter({ text: `Tổng cộng ${queue.songs.length} bài hát` });

        await interaction.reply({ embeds: [embed] });
    },

    async handleVolume(interaction, queue, volume) {
        if (!queue || !queue.player) {
            return await interaction.reply({
                content: '❌ Không có nhạc nào đang phát!',
                ephemeral: true
            });
        }

        const newVolume = volume / 100;
        queue.setVolume(newVolume);
        await interaction.reply(`🔊 Đã điều chỉnh âm lượng thành ${volume}%`);
    },

    async handleNowPlaying(interaction, queue) {
        if (!queue || !queue.currentSong) {
            return await interaction.reply({
                content: '❌ Không có bài hát nào đang phát!',
                ephemeral: true
            });
        }

        const song = queue.currentSong;
        const embed = new EmbedBuilder()
            .setColor('#ff9900')
            .setTitle('🎵 Đang phát')
            .setDescription(`**${song.title}**`)
            .setThumbnail(song.thumbnail)
            .addFields(
                { name: 'Thời lượng', value: this.formatDuration(song.duration), inline: true },
                { name: 'Yêu cầu bởi', value: song.requester, inline: true },
                { name: 'Âm lượng', value: `${Math.round(queue.volume * 100)}%`, inline: true }
            );

        await interaction.reply({ embeds: [embed] });
    },

    async handleLeave(interaction, queue) {
        if (!queue) {
            return await interaction.reply({
                content: '❌ Bot không ở trong kênh voice nào!',
                ephemeral: true
            });
        }

        queue.destroy();
        interaction.client.queues.delete(interaction.guild.id);
        await interaction.reply('👋 Đã rời khỏi kênh voice');
    },

    async handleClearQueue(interaction, queue) {
        if (!queue) {
            return await interaction.reply({
                content: '❌ Hàng đợi đã trống!',
                ephemeral: true
            });
        }

        const count = queue.songs.length;
        queue.clearQueue();
        await interaction.reply(`🗑️ Đã xóa ${count} bài hát khỏi hàng đợi`);
    },

    async handleShuffle(interaction, queue) {
        if (!queue || queue.songs.length <= 1) {
            return await interaction.reply({
                content: '❌ Cần ít nhất 2 bài hát để trộn!',
                ephemeral: true
            });
        }

        queue.shuffle();
        await interaction.reply('🔀 Đã trộn thứ tự bài hát trong hàng đợi');
    },

    formatDuration(seconds) {
        const mins = Math.floor(seconds / 60);
        const secs = seconds % 60;
        return `${mins}:${secs.toString().padStart(2, '0')}`;
    },

    async executePrefix(message, args, action) {
        const guildId = message.guild.id;
        const voiceChannel = message.member.voice.channel;
        
        // Kiểm tra xem user có trong voice channel không
        if (!voiceChannel && ['play', 'pause', 'resume', 'stop', 'skip', 'volume'].includes(action)) {
            return await message.reply('❌ Bạn phải ở trong một kênh voice để sử dụng lệnh này!');
        }

        // Lấy queue của guild
        let queue = message.client.queues.get(guildId);
        
        switch (action) {
            case 'play':
                if (args.length === 0) {
                    return await message.reply('❌ Vui lòng cung cấp URL YouTube!\nVí dụ: `kplay https://youtube.com/watch?v=...`');
                }
                const url = args.join(' ');
                await this.handlePlayPrefix(message, voiceChannel, url);
                break;
                
            case 'pause':
                await this.handlePausePrefix(message, queue);
                break;
                
            case 'resume':
                await this.handleResumePrefix(message, queue);
                break;
                
            case 'stop':
                await this.handleStopPrefix(message, queue);
                break;
                
            case 'skip':
                await this.handleSkipPrefix(message, queue);
                break;
                
            case 'queue':
                await this.handleQueuePrefix(message, queue);
                break;
                
            case 'volume':
                if (args.length === 0) {
                    return await message.reply('❌ Vui lòng cung cấp mức âm lượng (1-100)!\nVí dụ: `kvolume 50`');
                }
                const volume = parseInt(args[0]);
                await this.handleVolumePrefix(message, queue, volume);
                break;
                
            case 'nowplaying':
                await this.handleNowPlayingPrefix(message, queue);
                break;
                
            case 'leave':
                await this.handleLeavePrefix(message, queue);
                break;
                
            case 'clear':
                await this.handleClearQueuePrefix(message, queue);
                break;
                
            case 'shuffle':
                await this.handleShufflePrefix(message, queue);
                break;
                
            case 'help':
                await this.handleHelpPrefix(message);
                break;
        }
    },

    async handlePlayPrefix(message, voiceChannel, url) {
        const loadingMessage = await message.reply('🔄 Đang tải nhạc...');
        
        try {
            const guildId = message.guild.id;
            let queue = message.client.queues.get(guildId);
            
            // Tạo queue mới nếu chưa có
            if (!queue) {
                queue = new Queue(guildId);
                message.client.queues.set(guildId, queue);
            }

            // Kiểm tra loại URL
            if (YouTube.isValidPlaylistURL(url)) {
                // Xử lý YouTube playlist
                await this.handleYouTubePlaylist(message, loadingMessage, voiceChannel, url, queue);
            } else if (Spotify.isValidSpotifyURL(url)) {
                // Xử lý Spotify URL
                await this.handleSpotifyUrl(message, loadingMessage, voiceChannel, url, queue);
            } else if (YouTube.isValidURL(url)) {
                // Xử lý YouTube video đơn lẻ
                await this.handleYouTubeVideo(message, loadingMessage, voiceChannel, url, queue);
            } else {
                return await loadingMessage.edit('❌ URL không hợp lệ! Hỗ trợ YouTube video/playlist và Spotify track/album/playlist.');
            }

        } catch (error) {
            console.error('Lỗi khi phát nhạc:', error);
            await loadingMessage.edit('❌ Đã xảy ra lỗi khi phát nhạc. Vui lòng thử lại!');
        }
    },

    async handleYouTubeVideo(message, loadingMessage, voiceChannel, url, queue) {
        const videoInfo = await YouTube.getVideoInfo(url);
        
        if (!videoInfo) {
            return await loadingMessage.edit('❌ Không thể tìm thấy video hoặc URL không hợp lệ!');
        }

        const song = {
            title: videoInfo.videoDetails.title,
            url: videoInfo.videoDetails.video_url,
            duration: videoInfo.videoDetails.lengthSeconds,
            thumbnail: videoInfo.videoDetails.thumbnails[0]?.url,
            requester: message.author.username
        };

        queue.addSong(song);

        const embed = new EmbedBuilder()
            .setColor('#00ff00')
            .setTitle('🎵 Đã thêm vào hàng đợi')
            .setDescription(`**${song.title}**`)
            .setThumbnail(song.thumbnail)
            .addFields(
                { name: 'Thời lượng', value: this.formatDuration(song.duration), inline: true },
                { name: 'Yêu cầu bởi', value: song.requester, inline: true },
                { name: 'Vị trí trong hàng đợi', value: `${queue.songs.length}`, inline: true }
            );

        await loadingMessage.edit({ content: '', embeds: [embed] });

        if (!queue.player || !queue.connection) {
            await this.createPlayerPrefix(message, voiceChannel, queue);
        }

        if (queue.songs.length === 1) {
            await this.playNextSong(queue);
        }
    },

    async handleYouTubePlaylist(message, loadingMessage, voiceChannel, url, queue) {
        await loadingMessage.edit('🔄 Đang tải playlist YouTube...');
        
        const playlistInfo = await YouTube.getPlaylistInfo(url);
        
        if (!playlistInfo) {
            return await loadingMessage.edit('❌ Không thể tải playlist YouTube!');
        }

        const validVideos = playlistInfo.videos.filter(video => 
            video.title !== '[Private video]' && 
            video.title !== '[Deleted video]' && 
            video.duration > 0
        );

        if (validVideos.length === 0) {
            return await loadingMessage.edit('❌ Playlist không có video hợp lệ!');
        }

        // Thêm tất cả video vào queue
        const addedSongs = [];
        for (const video of validVideos) {
            const song = {
                title: video.title,
                url: video.url,
                duration: video.duration,
                thumbnail: video.thumbnail,
                requester: message.author.username
            };
            queue.addSong(song);
            addedSongs.push(song);
        }

        const embed = new EmbedBuilder()
            .setColor('#00ff00')
            .setTitle('🎵 Đã thêm playlist vào hàng đợi')
            .setDescription(`**${playlistInfo.title}**`)
            .addFields(
                { name: 'Số bài hát', value: `${addedSongs.length}`, inline: true },
                { name: 'Yêu cầu bởi', value: message.author.username, inline: true },
                { name: 'Tổng thời lượng', value: this.formatDuration(addedSongs.reduce((total, song) => total + song.duration, 0)), inline: true }
            );

        await loadingMessage.edit({ content: '', embeds: [embed] });

        if (!queue.player || !queue.connection) {
            await this.createPlayerPrefix(message, voiceChannel, queue);
        }

        if (queue.songs.length === addedSongs.length) {
            await this.playNextSong(queue);
        }
    },

    async handleSpotifyUrl(message, loadingMessage, voiceChannel, url, queue) {
        const spotify = new Spotify();
        const urlInfo = Spotify.getSpotifyType(url);
        
        if (!urlInfo) {
            return await loadingMessage.edit('❌ URL Spotify không hợp lệ!');
        }

        await loadingMessage.edit('🔄 Đang tải từ Spotify...');

        try {
            if (urlInfo.type === 'track') {
                await this.handleSpotifyTrack(message, loadingMessage, voiceChannel, urlInfo.id, queue, spotify);
            } else if (urlInfo.type === 'playlist') {
                await this.handleSpotifyPlaylist(message, loadingMessage, voiceChannel, urlInfo.id, queue, spotify);
            } else if (urlInfo.type === 'album') {
                await this.handleSpotifyAlbum(message, loadingMessage, voiceChannel, urlInfo.id, queue, spotify);
            }
        } catch (error) {
            console.error('Lỗi khi xử lý Spotify:', error);
            await loadingMessage.edit('❌ Lỗi khi xử lý Spotify. Vui lòng kiểm tra lại URL!');
        }
    },

    async handleSpotifyTrack(message, loadingMessage, voiceChannel, trackId, queue, spotify) {
        const trackInfo = await spotify.getTrackInfo(trackId);
        
        if (!trackInfo) {
            return await loadingMessage.edit('❌ Không thể tải thông tin track Spotify!');
        }

        const song = {
            title: `${trackInfo.artist} - ${trackInfo.title}`,
            url: null, // Will be set when found on YouTube
            duration: trackInfo.duration,
            thumbnail: trackInfo.image,
            requester: message.author.username,
            spotifyData: trackInfo
        };

        queue.addSong(song);

        const embed = new EmbedBuilder()
            .setColor('#1DB954')
            .setTitle('🎵 Đã thêm track Spotify vào hàng đợi')
            .setDescription(`**${trackInfo.title}**`)
            .setThumbnail(trackInfo.image)
            .addFields(
                { name: 'Nghệ sĩ', value: trackInfo.artist, inline: true },
                { name: 'Album', value: trackInfo.album, inline: true },
                { name: 'Thời lượng', value: this.formatDuration(trackInfo.duration), inline: true },
                { name: 'Yêu cầu bởi', value: message.author.username, inline: true }
            )
            .setFooter({ text: 'Sẽ tự động tìm trên YouTube khi phát' });

        await loadingMessage.edit({ content: '', embeds: [embed] });

        if (!queue.player || !queue.connection) {
            await this.createPlayerPrefix(message, voiceChannel, queue);
        }

        if (queue.songs.length === 1) {
            await this.playNextSong(queue);
        }
    },

    async handleSpotifyPlaylist(message, loadingMessage, voiceChannel, playlistId, queue, spotify) {
        const playlistInfo = await spotify.getPlaylistInfo(playlistId);
        
        if (!playlistInfo) {
            return await loadingMessage.edit('❌ Không thể tải playlist Spotify!');
        }

        const addedSongs = [];
        for (const track of playlistInfo.tracks.slice(0, 50)) { // Giới hạn 50 bài để tránh spam
            const song = {
                title: `${track.artist} - ${track.title}`,
                url: null,
                duration: track.duration,
                thumbnail: track.image,
                requester: message.author.username,
                spotifyData: track
            };
            queue.addSong(song);
            addedSongs.push(song);
        }

        const embed = new EmbedBuilder()
            .setColor('#1DB954')
            .setTitle('🎵 Đã thêm playlist Spotify vào hàng đợi')
            .setDescription(`**${playlistInfo.title}**`)
            .addFields(
                { name: 'Số bài hát', value: `${addedSongs.length}`, inline: true },
                { name: 'Tác giả', value: playlistInfo.owner, inline: true },
                { name: 'Yêu cầu bởi', value: message.author.username, inline: true }
            )
            .setFooter({ text: 'Sẽ tự động tìm trên YouTube khi phát' });

        await loadingMessage.edit({ content: '', embeds: [embed] });

        if (!queue.player || !queue.connection) {
            await this.createPlayerPrefix(message, voiceChannel, queue);
        }

        if (queue.songs.length === addedSongs.length) {
            await this.playNextSong(queue);
        }
    },

    async handleSpotifyAlbum(message, loadingMessage, voiceChannel, albumId, queue, spotify) {
        const albumInfo = await spotify.getAlbumInfo(albumId);
        
        if (!albumInfo) {
            return await loadingMessage.edit('❌ Không thể tải album Spotify!');
        }

        const addedSongs = [];
        for (const track of albumInfo.tracks) {
            const song = {
                title: `${track.artist} - ${track.title}`,
                url: null,
                duration: track.duration,
                thumbnail: track.image,
                requester: message.author.username,
                spotifyData: track
            };
            queue.addSong(song);
            addedSongs.push(song);
        }

        const embed = new EmbedBuilder()
            .setColor('#1DB954')
            .setTitle('🎵 Đã thêm album Spotify vào hàng đợi')
            .setDescription(`**${albumInfo.title}**`)
            .addFields(
                { name: 'Nghệ sĩ', value: albumInfo.artist, inline: true },
                { name: 'Số bài hát', value: `${addedSongs.length}`, inline: true },
                { name: 'Ngày phát hành', value: albumInfo.release_date, inline: true },
                { name: 'Yêu cầu bởi', value: message.author.username, inline: true }
            )
            .setFooter({ text: 'Sẽ tự động tìm trên YouTube khi phát' });

        await loadingMessage.edit({ content: '', embeds: [embed] });

        if (!queue.player || !queue.connection) {
            await this.createPlayerPrefix(message, voiceChannel, queue);
        }

        if (queue.songs.length === addedSongs.length) {
            await this.playNextSong(queue);
        }
    },

    async createPlayerPrefix(message, voiceChannel, queue) {
        try {
            // Tạo kết nối voice
            const connection = joinVoiceChannel({
                channelId: voiceChannel.id,
                guildId: message.guild.id,
                adapterCreator: message.guild.voiceAdapterCreator,
                selfDeaf: false,
                selfMute: false,
            });

            // Tạo audio player
            const player = new Player(queue);
            
            // Gán player và connection vào queue
            queue.setPlayer(player);
            queue.setConnection(connection);
            
            // Subscribe connection với player
            connection.subscribe(player.audioPlayer);

            // Xử lý sự kiện kết nối
            connection.on(VoiceConnectionStatus.Ready, () => {
                console.log('Voice connection is ready!');
            });

            connection.on(VoiceConnectionStatus.Disconnected, async () => {
                try {
                    await Promise.race([
                        entersState(connection, VoiceConnectionStatus.Signalling, 5_000),
                        entersState(connection, VoiceConnectionStatus.Connecting, 5_000),
                    ]);
                } catch (error) {
                    console.log('Voice connection disconnected, cleaning up...');
                    queue.destroy();
                    message.client.queues.delete(message.guild.id);
                }
            });

            connection.on('error', (error) => {
                console.error('Voice connection error:', error);
            });

        } catch (error) {
            console.error('Error creating voice connection:', error);
            throw error;
        }
    },

    async handlePausePrefix(message, queue) {
        if (!queue || !queue.player) {
            return await message.reply('❌ Không có nhạc nào đang phát!');
        }

        queue.player.pause();
        await message.reply('⏸️ Đã tạm dừng nhạc');
    },

    async handleResumePrefix(message, queue) {
        if (!queue || !queue.player) {
            return await message.reply('❌ Không có nhạc nào đang phát!');
        }

        queue.player.resume();
        await message.reply('▶️ Đã tiếp tục phát nhạc');
    },

    async handleStopPrefix(message, queue) {
        if (!queue) {
            return await message.reply('❌ Không có nhạc nào đang phát!');
        }

        queue.destroy();
        message.client.queues.delete(message.guild.id);
        await message.reply('⏹️ Đã dừng nhạc và xóa hàng đợi');
    },

    async handleSkipPrefix(message, queue) {
        if (!queue || queue.songs.length === 0) {
            return await message.reply('❌ Không có bài hát nào để bỏ qua!');
        }

        const skippedSong = queue.songs.shift();
        await message.reply(`⏭️ Đã bỏ qua: **${skippedSong.title}**`);
        
        if (queue.songs.length > 0) {
            await this.playNextSong(queue);
        } else {
            queue.player.stop();
        }
    },

    async handleQueuePrefix(message, queue) {
        if (!queue || queue.songs.length === 0) {
            return await message.reply('❌ Hàng đợi trống!');
        }

        const embed = new EmbedBuilder()
            .setColor('#0099ff')
            .setTitle('🎵 Hàng đợi nhạc')
            .setDescription(
                queue.songs.slice(0, 10).map((song, index) => {
                    const status = index === 0 ? '🎵 **Đang phát:**' : `${index}.`;
                    return `${status} ${song.title} - *${song.requester}*`;
                }).join('\n')
            )
            .setFooter({ text: `Tổng cộng ${queue.songs.length} bài hát` });

        await message.reply({ embeds: [embed] });
    },

    async handleVolumePrefix(message, queue, volume) {
        if (!queue || !queue.player) {
            return await message.reply('❌ Không có nhạc nào đang phát!');
        }

        if (isNaN(volume) || volume < 1 || volume > 100) {
            return await message.reply('❌ Âm lượng phải từ 1 đến 100!');
        }

        const newVolume = volume / 100;
        queue.setVolume(newVolume);
        await message.reply(`🔊 Đã điều chỉnh âm lượng thành ${volume}%`);
    },

    async handleNowPlayingPrefix(message, queue) {
        if (!queue || !queue.currentSong) {
            return await message.reply('❌ Không có bài hát nào đang phát!');
        }

        const song = queue.currentSong;
        const embed = new EmbedBuilder()
            .setColor('#ff9900')
            .setTitle('🎵 Đang phát')
            .setDescription(`**${song.title}**`)
            .setThumbnail(song.thumbnail)
            .addFields(
                { name: 'Thời lượng', value: this.formatDuration(song.duration), inline: true },
                { name: 'Yêu cầu bởi', value: song.requester, inline: true },
                { name: 'Âm lượng', value: `${Math.round(queue.volume * 100)}%`, inline: true }
            );

        await message.reply({ embeds: [embed] });
    },

    async handleLeavePrefix(message, queue) {
        if (!queue) {
            return await message.reply('❌ Bot không ở trong kênh voice nào!');
        }

        queue.destroy();
        message.client.queues.delete(message.guild.id);
        await message.reply('👋 Đã rời khỏi kênh voice');
    },

    async handleClearQueuePrefix(message, queue) {
        if (!queue) {
            return await message.reply('❌ Hàng đợi đã trống!');
        }

        const count = queue.songs.length;
        queue.clearQueue();
        await message.reply(`🗑️ Đã xóa ${count} bài hát khỏi hàng đợi`);
    },

    async handleShufflePrefix(message, queue) {
        if (!queue || queue.songs.length <= 1) {
            return await message.reply('❌ Cần ít nhất 2 bài hát để trộn!');
        }

        queue.shuffle();
        await message.reply('🔀 Đã trộn thứ tự bài hát trong hàng đợi');
    },

    async handleHelpPrefix(message) {
        const embed = new EmbedBuilder()
            .setColor('#0099ff')
            .setTitle('🎵 Hướng dẫn sử dụng Bot Music')
            .setDescription('Danh sách các lệnh có sẵn:')
            .addFields(
                { name: '🎵 Phát nhạc', value: '`kplay <URL>` hoặc `kp <URL>`', inline: true },
                { name: '⏸️ Tạm dừng', value: '`kpause`', inline: true },
                { name: '▶️ Tiếp tục', value: '`kresume`', inline: true },
                { name: '⏹️ Dừng', value: '`kstop`', inline: true },
                { name: '⏭️ Bỏ qua', value: '`kskip`', inline: true },
                { name: '📋 Hàng đợi', value: '`kqueue`', inline: true },
                { name: '🔊 Âm lượng', value: '`kvolume <1-100>`', inline: true },
                { name: '🎵 Đang phát', value: '`knp`', inline: true },
                { name: '👋 Rời khỏi', value: '`kleave`', inline: true },
                { name: '🗑️ Xóa hàng đợi', value: '`kclear`', inline: true },
                { name: '🔀 Trộn bài', value: '`kshuffle`', inline: true },
                { name: '❓ Trợ giúp', value: '`khelp`', inline: true }
            )
            .addField('\u200b', '\u200b', false)
            .addFields(
                { name: '🔨 Cấm thành viên', value: '`kban @user <lý do>`', inline: true },
                { name: '👢 Đuổi thành viên', value: '`kkick @user <lý do>`', inline: true },
                { name: '🖼️ Xem avatar', value: '`kavatar @user`', inline: true },
                { name: '🎤 Thời gian voice', value: '`kvoice @user`', inline: true },
                { name: '🔐 Quyền cần thiết', value: 'Kick/Ban Members cho lệnh quản lý', inline: true },
                { name: '📝 Lưu ý', value: 'Không thể thao tác với thành viên có vai trò cao hơn', inline: true }
            )
            .addField('\u200b', '\u200b', false)
            .addFields(
                { name: '🎬 Hỗ trợ YouTube', value: '• Video đơn lẻ\n• Playlist (tất cả video)', inline: true },
                { name: '🎵 Hỗ trợ Spotify', value: '• Track đơn lẻ\n• Album (tất cả track)\n• Playlist (tối đa 50 track)', inline: true },
                { name: '📝 Lưu ý', value: 'Spotify sẽ tự động tìm trên YouTube khi phát', inline: true }
            )
            .setFooter({ text: 'Bot Music Việt Nam 24/7 - Hỗ trợ YouTube & Spotify' });

        await message.reply({ embeds: [embed] });
    }
};
