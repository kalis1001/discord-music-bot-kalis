const { Client, GatewayIntentBits, Collection } = require("discord.js");
const { joinVoiceChannel } = require("@discordjs/voice");
const config = require("./config");
const fs = require("fs");
const path = require("path");
const express = require("express");

// Tạo Discord client
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildVoiceStates,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
    ],
});

// Khởi tạo collections
client.commands = new Collection();
client.queues = new Collection();
client.players = new Collection();

// Load commands
const commandsPath = path.join(__dirname, "commands");
const commandFiles = fs
    .readdirSync(commandsPath)
    .filter((file) => file.endsWith(".js"));

for (const file of commandFiles) {
    const filePath = path.join(commandsPath, file);
    const command = require(filePath);
    client.commands.set(command.data.name, command);
}

// Load events
const eventsPath = path.join(__dirname, "events");
const eventFiles = fs
    .readdirSync(eventsPath)
    .filter((file) => file.endsWith(".js"));

for (const file of eventFiles) {
    const filePath = path.join(eventsPath, file);
    const event = require(filePath);
    if (event.once) {
        client.once(event.name, (...args) => event.execute(...args));
    } else {
        client.on(event.name, (...args) => event.execute(...args));
    }
}

// Message handler for prefix commands
client.on("messageCreate", async (message) => {
    if (message.author.bot) return;
    if (!message.content.startsWith(config.prefix)) return;

    const args = message.content.slice(config.prefix.length).trim().split(/ +/);
    const commandName = args.shift().toLowerCase();

    if (["play", "p", "kplay", "kp"].includes(commandName)) {
        const musicCommand = require("./commands/music");
        await musicCommand.executePrefix(message, args, "play");
    } else if (["pause", "tam_dung"].includes(commandName)) {
        const musicCommand = require("./commands/music");
        await musicCommand.executePrefix(message, args, "pause");
    } else if (["resume", "tiep_tuc"].includes(commandName)) {
        const musicCommand = require("./commands/music");
        await musicCommand.executePrefix(message, args, "resume");
    } else if (["stop", "dung"].includes(commandName)) {
        const musicCommand = require("./commands/music");
        await musicCommand.executePrefix(message, args, "stop");
    } else if (["skip", "bo_qua"].includes(commandName)) {
        const musicCommand = require("./commands/music");
        await musicCommand.executePrefix(message, args, "skip");
    } else if (["queue", "hang_doi"].includes(commandName)) {
        const musicCommand = require("./commands/music");
        await musicCommand.executePrefix(message, args, "queue");
    } else if (["volume", "am_luong"].includes(commandName)) {
        const musicCommand = require("./commands/music");
        await musicCommand.executePrefix(message, args, "volume");
    } else if (["nowplaying", "np", "dang_phat"].includes(commandName)) {
        const musicCommand = require("./commands/music");
        await musicCommand.executePrefix(message, args, "nowplaying");
    } else if (["leave", "thoat"].includes(commandName)) {
        const musicCommand = require("./commands/music");
        await musicCommand.executePrefix(message, args, "leave");
    } else if (["clear", "xoa_hang_doi"].includes(commandName)) {
        const musicCommand = require("./commands/music");
        await musicCommand.executePrefix(message, args, "clear");
    } else if (["shuffle", "tron_bai"].includes(commandName)) {
        const musicCommand = require("./commands/music");
        await musicCommand.executePrefix(message, args, "shuffle");
    } else if (["help", "tro_giup"].includes(commandName)) {
        const musicCommand = require("./commands/music");
        await musicCommand.executePrefix(message, args, "help");
    } else if (["ban", "cam"].includes(commandName)) {
        const adminCommand = require("./commands/admin");
        await adminCommand.executePrefix(message, args, "ban");
    } else if (["kick", "duoi"].includes(commandName)) {
        const adminCommand = require("./commands/admin");
        await adminCommand.executePrefix(message, args, "kick");
    } else if (["avatar", "avt"].includes(commandName)) {
        const adminCommand = require("./commands/admin");
        await adminCommand.executePrefix(message, args, "avatar");
    } else if (["voicetime", "vt", "voice"].includes(commandName)) {
        const adminCommand = require("./commands/admin");
        await adminCommand.executePrefix(message, args, "voicetime");
    }
});

client.on("error", console.error);
client.on("warn", console.warn);
process.on("unhandledRejection", (error) => {
    console.error("Unhandled promise rejection:", error);
});

// Keep-alive HTTP server for 24/7 uptime
const app = express();
const port = 3000;

app.get("/", (req, res) => {
    res.json({
        status: "Bot is online",
        timestamp: new Date().toISOString(),
        uptime: process.uptime(),
        guilds: client.guilds.cache.size,
        activeQueues: client.queues.size,
    });
});

app.get("/health", (req, res) => {
    res.json({
        status: "healthy",
        memory: process.memoryUsage(),
        uptime: process.uptime(),
        botStatus: client.isReady() ? "ready" : "not ready",
    });
});

app.listen(port, "0.0.0.0", () => {
    console.log(`🌐 Keep-alive server running on port ${port}`);
});

setInterval(() => {
    console.log("🔄 Bot is still alive at", new Date().toLocaleString());
}, 300000);

client.on("shardReconnecting", () => {
    console.log("🔄 Bot is reconnecting...");
});

client.on("shardResume", () => {
    console.log("✅ Bot has resumed connection");
});

client.login(config.token);
