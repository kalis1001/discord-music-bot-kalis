const config = {
    token: process.env.DISCORD_TOKEN || 'YOUR_DISCORD_BOT_TOKEN',
    clientId: process.env.DISCORD_CLIENT_ID || 'YOUR_CLIENT_ID',
    guildId: process.env.DISCORD_GUILD_ID || 'YOUR_GUILD_ID', // Để trống nếu muốn global commands
    prefix: 'k',
    maxQueueSize: 100,
    defaultVolume: 0.5,
    maxVolume: 1.0,
    minVolume: 0.1
};

module.exports = config;
