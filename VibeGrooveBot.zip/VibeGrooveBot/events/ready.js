const { Events } = require('discord.js');

module.exports = {
    name: Events.ClientReady,
    once: true,
    execute(client) {
        console.log(`✅ Bot đã sẵn sàng! Đã đăng nhập với tên ${client.user.tag}`);
        
        // Thiết lập trạng thái hoạt động
        client.user.setActivity('🎵 Nhạc Việt 24/7', { type: 'LISTENING' });
        
        console.log(`🎵 Bot đang hoạt động trên ${client.guilds.cache.size} server(s)`);
        console.log(`📋 Đã tải ${client.commands.size} lệnh`);
    },
};
