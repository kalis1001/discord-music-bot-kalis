const ytdl = require('@distube/ytdl-core');
const ytpl = require('ytpl');
const { createReadStream } = require('fs');

class YouTube {
    static async getVideoInfo(query) {
        try {
            // Kiểm tra xem có phải là URL YouTube không
            if (ytdl.validateURL(query)) {
                const info = await ytdl.getInfo(query, {
                    requestOptions: {
                        headers: {
                            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                            'Cookie': 'CONSENT=YES+cb.20210328-17-p0.en+FX+153',
                            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
                            'Accept-Language': 'en-US,en;q=0.9',
                            'Accept-Encoding': 'gzip, deflate',
                            'Connection': 'keep-alive',
                            'Upgrade-Insecure-Requests': '1',
                            'Sec-Fetch-Dest': 'document',
                            'Sec-Fetch-Mode': 'navigate',
                            'Sec-Fetch-Site': 'none',
                            'Sec-Fetch-User': '?1',
                            'Sec-Ch-Ua': '"Not_A Brand";v="8", "Chromium";v="120", "Google Chrome";v="120"',
                            'Sec-Ch-Ua-Mobile': '?0',
                            'Sec-Ch-Ua-Platform': '"Windows"'
                        }
                    }
                });
                return info;
            } else {
                // Nếu không phải URL, tìm kiếm bài hát (đơn giản hóa)
                // Trong thực tế, bạn có thể sử dụng YouTube Search API
                throw new Error('Vui lòng cung cấp URL YouTube hợp lệ');
            }
        } catch (error) {
            console.error('Lỗi khi lấy thông tin video:', error);
            return null;
        }
    }

    static async getAudioStream(url) {
        try {
            const stream = ytdl(url, {
                filter: 'audioonly',
                quality: 'highestaudio',
                highWaterMark: 1 << 25, // 32MB buffer
                requestOptions: {
                    headers: {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                        'Cookie': 'CONSENT=YES+cb.20210328-17-p0.en+FX+153',
                        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
                        'Accept-Language': 'en-US,en;q=0.9',
                        'Accept-Encoding': 'gzip, deflate',
                        'Connection': 'keep-alive',
                        'Upgrade-Insecure-Requests': '1',
                        'Sec-Fetch-Dest': 'document',
                        'Sec-Fetch-Mode': 'navigate',
                        'Sec-Fetch-Site': 'none',
                        'Sec-Fetch-User': '?1',
                        'Sec-Ch-Ua': '"Not_A Brand";v="8", "Chromium";v="120", "Google Chrome";v="120"',
                        'Sec-Ch-Ua-Mobile': '?0',
                        'Sec-Ch-Ua-Platform': '"Windows"'
                    }
                },
                dlChunkSize: 0,
                bitrate: 128,
                fmt: 'mp3'
            });

            return stream;
        } catch (error) {
            console.error('Lỗi khi lấy stream âm thanh:', error);
            throw error;
        }
    }

    static formatDuration(seconds) {
        const hours = Math.floor(seconds / 3600);
        const minutes = Math.floor((seconds % 3600) / 60);
        const secs = seconds % 60;

        if (hours > 0) {
            return `${hours}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
        } else {
            return `${minutes}:${secs.toString().padStart(2, '0')}`;
        }
    }

    static isValidURL(string) {
        return ytdl.validateURL(string);
    }

    static async searchYouTube(query) {
        // Placeholder cho tính năng tìm kiếm
        // Bạn có thể tích hợp với YouTube Search API hoặc thư viện khác
        throw new Error('Tính năng tìm kiếm chưa được triển khai. Vui lòng sử dụng URL YouTube trực tiếp.');
    }

    static async getPlaylistInfo(playlistUrl) {
        try {
            if (!this.isValidPlaylistURL(playlistUrl)) {
                throw new Error('URL playlist không hợp lệ');
            }

            const playlist = await ytpl(playlistUrl);
            const videos = playlist.items.map(item => ({
                title: item.title,
                url: item.shortUrl,
                duration: item.durationSec,
                thumbnail: item.thumbnails[0]?.url,
                author: item.author.name
            }));

            return {
                title: playlist.title,
                description: playlist.description,
                videoCount: playlist.estimatedItemCount,
                videos: videos
            };
        } catch (error) {
            console.error('Lỗi khi lấy thông tin playlist:', error);
            return null;
        }
    }

    static isValidPlaylistURL(url) {
        const playlistRegex = /(?:https?:\/\/)?(?:www\.)?youtube\.com\/(?:playlist\?list=|watch\?v=.*&list=)([a-zA-Z0-9_-]+)/;
        return playlistRegex.test(url);
    }

    static extractVideoId(url) {
        try {
            return ytdl.getVideoID(url);
        } catch (error) {
            return null;
        }
    }

    static async getVideoDetails(url) {
        try {
            const info = await ytdl.getInfo(url, {
                requestOptions: {
                    headers: {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                        'Cookie': 'CONSENT=YES+cb.20210328-17-p0.en+FX+153',
                        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
                        'Accept-Language': 'en-US,en;q=0.9'
                    }
                }
            });
            const details = info.videoDetails;
            
            return {
                title: details.title,
                description: details.description,
                lengthSeconds: parseInt(details.lengthSeconds),
                viewCount: details.viewCount,
                author: details.author.name,
                uploadDate: details.uploadDate,
                thumbnail: details.thumbnails[0]?.url,
                url: details.video_url
            };
        } catch (error) {
            console.error('Lỗi khi lấy chi tiết video:', error);
            return null;
        }
    }

    static async validateVideo(url) {
        try {
            if (!ytdl.validateURL(url)) {
                return { valid: false, reason: 'URL không hợp lệ' };
            }

            const info = await ytdl.getInfo(url, {
                requestOptions: {
                    headers: {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                        'Cookie': 'CONSENT=YES+cb.20210328-17-p0.en+FX+153',
                        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
                        'Accept-Language': 'en-US,en;q=0.9'
                    }
                }
            });
            const details = info.videoDetails;

            // Kiểm tra xem video có bị chặn không
            if (details.isLiveContent) {
                return { valid: false, reason: 'Không thể phát livestream' };
            }

            // Kiểm tra độ dài video (tối đa 1 giờ = 3600 giây)
            if (parseInt(details.lengthSeconds) > 3600) {
                return { valid: false, reason: 'Video quá dài (tối đa 1 giờ)' };
            }

            return { valid: true, info: details };
        } catch (error) {
            return { valid: false, reason: 'Không thể truy cập video' };
        }
    }
}

module.exports = YouTube;
