class Queue {
    constructor(guildId) {
        this.guildId = guildId;
        this.songs = [];
        this.currentSong = null;
        this.player = null;
        this.connection = null;
        this.volume = 0.5;
        this.isPlaying = false;
        this.isPaused = false;
    }

    addSong(song) {
        this.songs.push(song);
    }

    removeSong(index) {
        if (index >= 0 && index < this.songs.length) {
            return this.songs.splice(index, 1)[0];
        }
        return null;
    }

    clearQueue() {
        this.songs = [];
        this.currentSong = null;
    }

    shuffle() {
        // Giữ bài đầu tiên (đang phát) và trộn các bài còn lại
        if (this.songs.length > 1) {
            const currentSong = this.songs[0];
            const restSongs = this.songs.slice(1);
            
            // Fisher-Yates shuffle
            for (let i = restSongs.length - 1; i > 0; i--) {
                const j = Math.floor(Math.random() * (i + 1));
                [restSongs[i], restSongs[j]] = [restSongs[j], restSongs[i]];
            }
            
            this.songs = [currentSong, ...restSongs];
        }
    }

    setPlayer(player) {
        this.player = player;
    }

    setConnection(connection) {
        this.connection = connection;
    }

    setVolume(volume) {
        this.volume = Math.max(0.1, Math.min(1.0, volume));
        if (this.player && this.player.audioPlayer) {
            this.player.setVolume(this.volume);
        }
    }

    destroy() {
        if (this.player) {
            this.player.stop();
        }
        if (this.connection) {
            this.connection.destroy();
        }
        this.songs = [];
        this.currentSong = null;
        this.player = null;
        this.connection = null;
    }

    isEmpty() {
        return this.songs.length === 0;
    }

    getPosition(song) {
        return this.songs.indexOf(song);
    }

    peek() {
        return this.songs[0] || null;
    }

    size() {
        return this.songs.length;
    }
}

module.exports = Queue;
