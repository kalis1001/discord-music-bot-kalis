const { createAudioPlayer, AudioPlayerStatus, createAudioResource } = require('@discordjs/voice');
const YouTube = require('./youtube');

class Player {
    constructor(queue) {
        this.queue = queue;
        this.audioPlayer = createAudioPlayer();
        this.volume = 0.5;
        this.setupEventListeners();
    }

    setupEventListeners() {
        this.audioPlayer.on(AudioPlayerStatus.Idle, () => {
            // Bài hát đã kết thúc, chuyển sang bài tiếp theo
            if (this.queue.songs.length > 0) {
                this.queue.songs.shift(); // Xóa bài vừa phát
                if (this.queue.songs.length > 0) {
                    this.playNext();
                } else {
                    this.queue.currentSong = null;
                    this.queue.isPlaying = false;
                }
            }
        });

        this.audioPlayer.on(AudioPlayerStatus.Playing, () => {
            this.queue.isPlaying = true;
            this.queue.isPaused = false;
        });

        this.audioPlayer.on(AudioPlayerStatus.Paused, () => {
            this.queue.isPaused = true;
        });

        this.audioPlayer.on('error', (error) => {
            console.error('Audio player error:', error);
            // Bỏ qua bài hát lỗi và chuyển sang bài tiếp theo
            if (this.queue.songs.length > 0) {
                this.queue.songs.shift();
                if (this.queue.songs.length > 0) {
                    this.playNext();
                }
            }
        });
    }

    async play(resource) {
        this.audioPlayer.play(resource);
    }

    async playNext() {
        if (this.queue.songs.length === 0) {
            this.queue.currentSong = null;
            this.queue.isPlaying = false;
            return;
        }

        const song = this.queue.songs[0];
        
        try {
            let audioUrl = song.url;
            
            // If this is a Spotify song, search for it on YouTube
            if (!audioUrl && song.spotifyData) {
                console.log(`Tìm kiếm YouTube cho: ${song.spotifyData.searchQuery}`);
                // For now, we'll skip Spotify songs that don't have YouTube URLs
                // In a production environment, you would integrate with YouTube Search API
                console.log(`Bỏ qua bài Spotify: ${song.title} - cần YouTube Search API`);
                this.queue.songs.shift();
                if (this.queue.songs.length > 0) {
                    await this.playNext();
                }
                return;
            }
            
            if (!audioUrl) {
                throw new Error('Không có URL âm thanh');
            }

            const stream = await YouTube.getAudioStream(audioUrl);
            const resource = createAudioResource(stream, {
                inputType: stream.type,
                metadata: song
            });

            this.queue.currentSong = song;
            this.audioPlayer.play(resource);
            
        } catch (error) {
            console.error('Lỗi khi phát bài hát:', error);
            // Bỏ bài hát lỗi và thử bài tiếp theo
            this.queue.songs.shift();
            if (this.queue.songs.length > 0) {
                await this.playNext();
            }
        }
    }

    pause() {
        if (this.audioPlayer.state.status === AudioPlayerStatus.Playing) {
            this.audioPlayer.pause();
            return true;
        }
        return false;
    }

    resume() {
        if (this.audioPlayer.state.status === AudioPlayerStatus.Paused) {
            this.audioPlayer.unpause();
            return true;
        }
        return false;
    }

    stop() {
        this.audioPlayer.stop();
        this.queue.isPlaying = false;
        this.queue.isPaused = false;
    }

    setVolume(volume) {
        this.volume = Math.max(0.1, Math.min(1.0, volume));
        // Volume control được xử lý trong createAudioResource
    }

    getStatus() {
        return {
            status: this.audioPlayer.state.status,
            isPlaying: this.queue.isPlaying,
            isPaused: this.queue.isPaused,
            currentSong: this.queue.currentSong,
            volume: this.volume
        };
    }
}

module.exports = Player;
