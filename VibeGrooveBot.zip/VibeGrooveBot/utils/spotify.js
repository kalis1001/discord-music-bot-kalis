const SpotifyWebApi = require('spotify-web-api-node');
const YouTube = require('./youtube');

class Spotify {
    constructor() {
        this.spotifyApi = new SpotifyWebApi({
            clientId: process.env.SPOTIFY_CLIENT_ID,
            clientSecret: process.env.SPOTIFY_CLIENT_SECRET
        });
    }

    async authenticate() {
        try {
            const data = await this.spotifyApi.clientCredentialsGrant();
            this.spotifyApi.setAccessToken(data.body['access_token']);
            return true;
        } catch (error) {
            console.error('Lỗi khi xác thực Spotify:', error);
            return false;
        }
    }

    static isValidSpotifyURL(url) {
        const spotifyRegex = /^https?:\/\/open\.spotify\.com\/(track|album|playlist)\/([a-zA-Z0-9]+)/;
        return spotifyRegex.test(url);
    }

    static getSpotifyType(url) {
        const match = url.match(/^https?:\/\/open\.spotify\.com\/(track|album|playlist)\/([a-zA-Z0-9]+)/);
        if (match) {
            return {
                type: match[1],
                id: match[2]
            };
        }
        return null;
    }

    async getTrackInfo(trackId) {
        try {
            if (!await this.authenticate()) {
                throw new Error('Không thể xác thực Spotify');
            }

            const track = await this.spotifyApi.getTrack(trackId);
            const trackData = track.body;

            return {
                title: trackData.name,
                artist: trackData.artists.map(artist => artist.name).join(', '),
                album: trackData.album.name,
                duration: Math.floor(trackData.duration_ms / 1000),
                preview_url: trackData.preview_url,
                external_urls: trackData.external_urls.spotify,
                image: trackData.album.images[0]?.url,
                searchQuery: `${trackData.artists[0].name} ${trackData.name}`
            };
        } catch (error) {
            console.error('Lỗi khi lấy thông tin track Spotify:', error);
            return null;
        }
    }

    async getPlaylistInfo(playlistId) {
        try {
            if (!await this.authenticate()) {
                throw new Error('Không thể xác thực Spotify');
            }

            const playlist = await this.spotifyApi.getPlaylist(playlistId);
            const playlistData = playlist.body;

            // Lấy tất cả tracks trong playlist
            const tracks = [];
            let offset = 0;
            const limit = 50;

            while (true) {
                const tracksResponse = await this.spotifyApi.getPlaylistTracks(playlistId, {
                    offset: offset,
                    limit: limit
                });

                const batchTracks = tracksResponse.body.items.map(item => {
                    if (item.track && item.track.type === 'track') {
                        return {
                            title: item.track.name,
                            artist: item.track.artists.map(artist => artist.name).join(', '),
                            album: item.track.album.name,
                            duration: Math.floor(item.track.duration_ms / 1000),
                            preview_url: item.track.preview_url,
                            external_urls: item.track.external_urls.spotify,
                            image: item.track.album.images[0]?.url,
                            searchQuery: `${item.track.artists[0].name} ${item.track.name}`
                        };
                    }
                    return null;
                }).filter(track => track !== null);

                tracks.push(...batchTracks);

                if (tracksResponse.body.items.length < limit) {
                    break;
                }
                offset += limit;
            }

            return {
                title: playlistData.name,
                description: playlistData.description,
                trackCount: playlistData.tracks.total,
                owner: playlistData.owner.display_name,
                image: playlistData.images[0]?.url,
                tracks: tracks
            };
        } catch (error) {
            console.error('Lỗi khi lấy thông tin playlist Spotify:', error);
            return null;
        }
    }

    async getAlbumInfo(albumId) {
        try {
            if (!await this.authenticate()) {
                throw new Error('Không thể xác thực Spotify');
            }

            const album = await this.spotifyApi.getAlbum(albumId);
            const albumData = album.body;

            const tracks = albumData.tracks.items.map(track => ({
                title: track.name,
                artist: track.artists.map(artist => artist.name).join(', '),
                album: albumData.name,
                duration: Math.floor(track.duration_ms / 1000),
                preview_url: track.preview_url,
                external_urls: track.external_urls.spotify,
                image: albumData.images[0]?.url,
                searchQuery: `${track.artists[0].name} ${track.name}`
            }));

            return {
                title: albumData.name,
                artist: albumData.artists.map(artist => artist.name).join(', '),
                trackCount: albumData.tracks.total,
                release_date: albumData.release_date,
                image: albumData.images[0]?.url,
                tracks: tracks
            };
        } catch (error) {
            console.error('Lỗi khi lấy thông tin album Spotify:', error);
            return null;
        }
    }

    async searchYouTubeForSpotifyTrack(spotifyTrack) {
        try {
            // Thử tìm kiếm video YouTube tương ứng
            // Đây là implementation đơn giản, bạn có thể cải thiện bằng YouTube Search API
            const searchQuery = `${spotifyTrack.artist} ${spotifyTrack.title}`;
            console.log(`Tìm kiếm YouTube cho: ${searchQuery}`);
            
            // Placeholder - trong thực tế bạn sẽ cần YouTube Search API
            // Hiện tại chỉ trả về thông tin để user có thể tự tìm
            return {
                title: spotifyTrack.title,
                artist: spotifyTrack.artist,
                searchQuery: searchQuery,
                spotifyUrl: spotifyTrack.external_urls,
                duration: spotifyTrack.duration,
                thumbnail: spotifyTrack.image
            };
        } catch (error) {
            console.error('Lỗi khi tìm kiếm YouTube:', error);
            return null;
        }
    }
}

module.exports = Spotify;