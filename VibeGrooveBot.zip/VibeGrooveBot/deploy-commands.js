const { REST, Routes } = require('discord.js');
const config = require('./config');
const fs = require('fs');
const path = require('path');

const commands = [];

// Lấy tất cả các file lệnh
const commandsPath = path.join(__dirname, 'commands');
const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));

for (const file of commandFiles) {
    const filePath = path.join(commandsPath, file);
    const command = require(filePath);
    commands.push(command.data.toJSON());
}

// Tạo REST instance
const rest = new REST({ version: '10' }).setToken(config.token);

// Deploy commands
(async () => {
    try {
        console.log(`🔄 Bắt đầu deploy ${commands.length} lệnh slash...`);

        // Lựa chọn deploy global hoặc guild-specific
        const data = config.guildId
            ? await rest.put(
                Routes.applicationGuildCommands(config.clientId, config.guildId),
                { body: commands }
            )
            : await rest.put(
                Routes.applicationCommands(config.clientId),
                { body: commands }
            );

        console.log(`✅ Đã deploy thành công ${data.length} lệnh slash!`);
        
        // Hiển thị danh sách lệnh
        console.log('📋 Danh sách lệnh:');
        data.forEach(command => {
            console.log(`  - /${command.name}: ${command.description}`);
        });

    } catch (error) {
        console.error('❌ Lỗi khi deploy lệnh:', error);
    }
})();
