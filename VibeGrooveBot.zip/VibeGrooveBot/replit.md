# Discord Music Bot

## Overview

This is a Discord music bot built with Node.js that provides music streaming capabilities from YouTube. The bot uses Discord.js v14 and Discord Voice API to handle voice connections and audio playback. It features a prefix-based command architecture with Vietnamese localization and 24/7 uptime capabilities.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Backend Architecture
- **Framework**: Node.js with Discord.js v14
- **Voice Handling**: @discordjs/voice for audio streaming
- **Command System**: Slash commands with subcommands
- **Event-Driven**: Event handlers for Discord interactions and bot lifecycle
- **Module Structure**: Utility classes for queue management, player control, and YouTube integration

### Key Design Decisions
- **Slash Commands**: Modern Discord slash command system instead of prefix commands for better UX
- **Queue System**: Per-guild queue management allowing multiple servers to use the bot simultaneously
- **Audio Streaming**: Direct YouTube audio streaming using ytdl-core
- **Error Handling**: Comprehensive error handling with user-friendly messages

## Key Components

### Command System
- **Location**: `/commands/music.js`, `/commands/admin.js`
- **Structure**: Prefix-based commands with "k" prefix
- **Music Commands**: kplay, kpause, kresume, kstop, kskip, kqueue, kvolume, knp, kleave, kclear, kshuffle, khelp
- **Admin Commands**: kban, kkick, kavatar, kvoice (requires appropriate permissions)
- **Localization**: Vietnamese command names and descriptions
- **Prefix**: "k" - allows commands like `kplay`, `kp`, `kpause`, `kresume`, etc.

### Event Handlers
- **InteractionCreate**: Handles slash command interactions with error handling
- **Ready**: Bot initialization and status setup

### Utility Classes
- **Queue**: Manages song queues per guild with methods for adding, removing, and shuffling songs
- **Player**: Audio player wrapper with event handling for playback state management
- **YouTube**: YouTube integration for video info retrieval and audio stream generation

### Configuration
- **Environment Variables**: Discord token, client ID, and guild ID
- **Audio Settings**: Volume controls, queue size limits, and audio quality parameters

## Data Flow

1. **Command Execution**: User triggers slash command → InteractionCreate event → Command handler
2. **Music Playback**: YouTube URL/search → Video info retrieval → Audio stream creation → Voice connection → Audio player
3. **Queue Management**: Songs added to guild-specific queue → Player processes queue sequentially → Auto-advance on song completion
4. **Voice Connection**: Bot joins voice channel → Creates audio player → Subscribes connection to player

## External Dependencies

### Core Dependencies
- **discord.js**: Discord API wrapper and client
- **@discordjs/voice**: Voice connection and audio streaming
- **@distube/ytdl-core**: YouTube video downloading and audio extraction (updated fork)
- **ytpl**: YouTube playlist parsing and video extraction  
- **spotify-web-api-node**: Spotify Web API integration
- **express**: HTTP server for keep-alive functionality

### Configuration Requirements
- Discord Bot Token
- Discord Application Client ID
- Guild ID (optional for guild-specific commands)
- Spotify Client ID and Secret (for Spotify integration)

## Deployment Strategy

### Command Deployment
- **Script**: `deploy-commands.js` for registering slash commands
- **Scope**: Configurable between guild-specific and global commands
- **Process**: Automatic command registration with Discord API

### Runtime
- **Entry Point**: `index.js` initializes client and loads commands/events
- **Environment**: Requires Node.js runtime with Discord bot permissions
- **Permissions**: Voice channel access, message sending, slash command usage

### Recent Updates (July 2025)
- **Playlist Support**: Added YouTube playlist support with automatic video extraction
- **Spotify Integration**: Full support for Spotify tracks, albums, and playlists
- **Enhanced URL Handling**: Auto-detection of URL types (YouTube video/playlist, Spotify track/album/playlist)
- **Improved Error Handling**: Better voice connection management and reconnection logic
- **24/7 Uptime**: Keep-alive server and auto-reconnect mechanisms
- **Admin Commands**: Added server management commands (ban, kick, avatar, voice time tracking)
- **YouTube Bot Detection Fix**: Updated headers and cookies to bypass "Sign in to confirm you're not a bot" errors

### Missing Implementation
- YouTube search functionality for Spotify tracks (requires YouTube Search API)
- No persistent data storage (queues reset on bot restart)
- No database integration for user preferences or statistics

### Production Considerations
- Bot requires "bot" and "applications.commands" scopes
- Voice channel permissions needed for music functionality
- YouTube API rate limiting considerations
- Memory management for audio streams and queues

### 24/7 Uptime Features
- **Keep-alive HTTP server**: Running on port 3000 for health checks
- **Auto-reconnect mechanism**: Handles Discord connection drops
- **Heartbeat system**: Logs activity every 5 minutes
- **Express endpoints**: `/` for status, `/health` for detailed metrics
- **Error handling**: Comprehensive error catching and recovery